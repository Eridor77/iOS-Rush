//
//  FirstViewController.swift
//  iOSapp
//
//  Created by Ruddy LAVALLOIR on 2/13/16.
//  Copyright © 2016 42. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class FirstViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
   
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
   
    let regionRadius: CLLocationDistance = 500
    let initialLocation = CLLocation(latitude: 48.89669080999876, longitude: 2.3184478282928467)
    let museumLocation = CLLocation(latitude: 48.8606111, longitude: 2.3376439999999548)
    let churchLocation = CLLocation(latitude: 48.8527288, longitude: 2.350563500000021)
    var index = Int()
    
    func centerMapOnLocation(location: CLLocation){
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    @IBOutlet weak var segment: UISegmentedControl!
    @IBAction func segmentChanged() {
        switch (segment.selectedSegmentIndex) {
        case 0:
            mapView.mapType = MKMapType.Standard
        case 1:
            mapView.mapType = MKMapType.Satellite
        case 2:
            mapView.mapType = MKMapType.Hybrid
        default:
            break
        }
    }
    
    @IBAction func LocationFinder(sender: UIButton) {
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
        self.mapView.showsUserLocation = true
        
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let location = locations.last
        let center = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0, longitudeDelta: 0))
        self.mapView.setRegion(region, animated: true)
        self.locationManager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError)
    {
        print("Errors: " + error.localizedDescription)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let school = CLLocationCoordinate2DMake(48.89669080999876, 2.3184478282928467)
        let schoolPin = MKPointAnnotation()
        schoolPin.coordinate = school
        schoolPin.title = "Ecole 42"
        schoolPin.subtitle = "Cybercafe, Hotel et Cinema"
        mapView.addAnnotation(schoolPin)
        
        let museum = CLLocationCoordinate2DMake(48.8606111, 2.3376439999999548)
        let museumPin = MKPointAnnotation()
        museumPin.coordinate = museum
        museumPin.title = "Louvre"
        museumPin.subtitle = "Somptueux Musee"
        mapView.addAnnotation(museumPin)
        
        let church = CLLocationCoordinate2DMake(48.8527288, 2.350563500000021)
        let churchPin = MKPointAnnotation()
        churchPin.coordinate = church
        churchPin.title = "Notre-Dame"
        churchPin.subtitle = "La fameuse cathedrale"
        mapView.addAnnotation(churchPin)
        
        centerMapOnLocation(initialLocation)
        
        switch (index) {
        case 1:
            centerMapOnLocation(initialLocation)
        case 2:
            centerMapOnLocation(museumLocation)
        case 3:
            centerMapOnLocation(churchLocation)
        default:
            break
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

